﻿Language: Python 3.6.0
Written by: Gordon Gao, Thomas , Kevin Ouellette, Monika 



Unzip project to desired folder.
Navigate to folder in command prompt and use the command in the following format to run:

python sample.py humidity=high #iterations stress=high 


Any number of observed nodes can be added. #iterations is an actual number. Make sure that it is node=state without a space as shown in the design doc.

We followed the same format we saw in the design document. We believe to have a fully working implementation that properly returns the expected probability, AME, total number of samples, non-rejected samples and time taken. 


In our report we have included the graphs for estimated probability and Absolute margin of error.

Files in zip:


sample.py
pDicts.py 
Assignment 3.docx


If there are any issues please let us know. Thank you!