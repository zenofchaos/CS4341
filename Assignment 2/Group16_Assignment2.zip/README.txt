﻿Language: Python 3.6.0
Written by: Gordon Gao, Thomas , Kevin Ouellette, Monika 



Unzip project to desired folder.
Navigate to folder in command prompt and use the command:
python optimize.py {hill,annealing,ga} text.txt 60

If you have issues using the command, the program will alert you of any mistakes.
You can also use the command 'python optimize.py -h' to access the help manual for the code.

We believe we have fully implemented each of the three algorithms. We have decided that simulated annealing is the best. Attached in the zipfile is our python files with our algorithms, our test file, and our tune file.

Files in zip:


annealing.py
genetic.py 
hill.py
optimize.py  ← The main python file to be run
test.txt  <- our testing file
tune.txt <- our tune file 
createTest.py <- Creates sample files
even_example.txt  Sample text files
odd_exaple.txt  


Our genetic is slightly worse performing, but all of our algorithms performs as they should. 


If there are any issues please let us know. Thank you!